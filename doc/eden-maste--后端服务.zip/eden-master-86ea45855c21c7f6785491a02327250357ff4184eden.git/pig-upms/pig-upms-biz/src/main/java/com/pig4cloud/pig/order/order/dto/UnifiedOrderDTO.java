package com.pig4cloud.pig.order.order.dto;

import lombok.Data;

/**
 * <p>Title: UnifiedOrderDTO</p
 * <p>Description: </p>
 *
 * @author 余新引
 * @date 2019年06月21日
 * @since 1.8
 */
@Data
public class UnifiedOrderDTO {
	private String openid;
	private String ordercode;
}
