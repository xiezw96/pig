package com.pig4cloud.pig.device.core.msg;

/**
 * @title: MsgConstants
 * @projectName eden
 * @description: TODO
 */
public class MsgConstants {
	/*** 协议定义 ***/
	public static final String PROTOCAL_TYPE_MQTT  = "mqtt";


}
