package com.pig4cloud.pig.quartz.tasks;

/**
 * <p>Title: TaskGroup</p
 * <p>Description: </p>
 *
 * @author 余新引
 * @date 2019年04月17日
 * @since 1.8
 */
public class TaskGroup {

	public static final String ORDER_KEY = "com.pig4cloud.pig.quartz.tasks.order";

	public static final String SALES_MACHINE_KEY = "com.pig4cloud.pig.quartz.tasks.salesmachine";

	public static final String AGENT_DAY_REPORT_KEY = "com.pig4cloud.pig.quartz.tasks.agentdayreport";
}
