package com.pig4cloud.pig.order.order.commons;

/**
 * <p>Title: OrderConstants</p
 * <p>Description: </p>
 *
 * @author 余新引
 * @date 2019年04月16日
 * @since 1.8
 */
public class OrderConstants {
	public static final int AGENT = 0;
	public static final int USER = 1;
}
