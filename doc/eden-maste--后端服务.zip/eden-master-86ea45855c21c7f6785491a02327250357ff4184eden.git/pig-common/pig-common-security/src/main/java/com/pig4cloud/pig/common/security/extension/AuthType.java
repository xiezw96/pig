package com.pig4cloud.pig.common.security.extension;

public enum AuthType {
	WX, QQ, CODE;
}
